var restify     =   require('restify');
var mongojs     =   require('mongojs');
var db          =   mongojs('mongodb://bookadmin:booksharedb123@ds023418.mlab.com:23418/bookshareapp', ['users','books']);
var server      =   restify.createServer();
server.use(restify.acceptParser(server.acceptable));
server.use(restify.queryParser());
server.use(restify.bodyParser());
server.use(restify.CORS());
server.use(restify.fullResponse());
restify.CORS.ALLOW_HEADERS.push('authorization');

// Cross Origin Request Sharing Permissions
server.use(function(req, res, next) {
    res.header('Access-Control-Allow-Origin', "*");
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});
 
server.listen(process.env.PORT || 9804, function () {
    console.log("Listening at ",process.env.PORT || 9804);
});

var users       =   require('./auth/users')(server, db);
var books       =   require('./books/bookservice')(server, db);