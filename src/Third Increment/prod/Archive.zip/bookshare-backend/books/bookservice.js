module.exports = function (server, db) {
    
    server.post('/bookshare/api/book/new', function(req, res, next) {
        var bookDetails = req.params;
        
        db.books.insert(bookDetails, function(err, book) {
            if(err) {
                res.writeHead(400, {
                    'Content-Type': "application/json; charset=utf-8"
                });
                res.end(JSON.stringify({
                    error:err,
                    message: "Unknown Error"
                }));
            }
            else {
                res.writeHead(200, {
                    'Content-Type': "application/json; charset=utf-8"
                });
                res.end(JSON.stringify(book));
            }
        });
        return next();
    });
    
    server.get('/bookshare/api/userbooks', function(req, res, next) {
        var user = req.params.email;
        
        db.books.find({
            email: user
        }, function(err, data){
            res.writeHead(200, {
                'Content-Type': "application/json; charset=utf-8"
            });
            res.end(JSON.stringify(data));
        });
        return next();
    });
    
}